# Sozie Android Assessment

Congratulations! Our team has progressed you to Round 2 for the Senior Android Developer role at Sozie. As part of a technical assessment, we ask that you complete a coding test.

For the coding test, you will complete Sub-Task 1. Create UI, highlighted in green in the table below. 

## Instructions
1. To get started clone the repository here.
2. Use the following assets to complete your work Measurement Screens & Assets
3. Email back a link to your repository when you are done

If any technical issues arise during the test, please contact muneeb@sozie.com for assistance.

## Deadline
Monday, June 15 5pm EST
Please budget 6 hours for this test.
If you do not think you can meet the deadline, please email us and let us know when you can submit by.

## Next Steps
We will assess your code and give you feedback regardless of whether you are successful or not. If you are successful we will make you an offer for the position.

Thank you,

Tahreem

